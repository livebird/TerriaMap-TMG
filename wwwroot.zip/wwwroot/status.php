<?php
print "success";
return 0;
?>

